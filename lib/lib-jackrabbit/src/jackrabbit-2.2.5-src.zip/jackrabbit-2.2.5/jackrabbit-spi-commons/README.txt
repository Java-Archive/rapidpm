=================================
Welcome to Jackrabbit SPI Commons
=================================

This is the SPI Commons component of the Apache Jackrabbit project.
This component contains generic utility classes that might be used
to build an SPI implementation.
In addition this component provides utilities used to convert JCR
name and path Strings as well as values to their corresponding SPI 
representation.
