package org.rapidpm.persistence.security.berechtigungen;

import org.apache.log4j.Logger;
import org.rapidpm.data.BaseFlatEntity;
import org.rapidpm.data.BaseOrmResult;
import org.rapidpm.ejb3.CRUDExecuter;
import org.rapidpm.logging.LogEventEntryWriterBean;
import org.rapidpm.logging.LoggerQualifier;
import org.rapidpm.persistence.DaoFactoryBean;
import org.rapidpm.persistence.system.security.berechtigungen.Berechtigung;
import org.rapidpm.persistence.system.security.berechtigungen.BerechtigungDAO;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.Collection;
import java.util.List;

/**
 * RapidPM - www.rapidpm.org
 * User: svenruppert
 * Date: 18.03.11
 * Time: 02:35
 * This is part of the RapidPM - www.rapidpm.org project. please contact sven.ruppert@neoscio.de
 */
@Stateless(name = "BerechtigungDAOEJB")
@WebService(name = "BerechtigungDAOWS")
public class BerechtigungDAOBean {
    public BerechtigungDAOBean() {
    }

    @Inject @LoggerQualifier
    private transient Logger logger;

    @EJB(beanName = "DaoFactoryEJB")
    private DaoFactoryBean daoFactoryBean;

    @EJB(beanName = "LogEventEntryWriterEJB")
    private LogEventEntryWriterBean logEventEntryWriterBean;


    private CRUDExecuter<FlatBerechtigung, Berechtigung, BerechtigungResult> crudExecuter = new CRUDExecuter<FlatBerechtigung, Berechtigung, BerechtigungResult>(BerechtigungResult.class) {
        @Override
        protected Berechtigung flatType2Type(final FlatBerechtigung flatTypeEntity) {
            final Long id = flatTypeEntity.getId();
            final Berechtigung typeObj;
            if (id == null || id == -1 || id == 0) {
                typeObj = new Berechtigung();
            } else {
                typeObj = findByID(id);
            }
            typeObj.setName(flatTypeEntity.getName());

            return typeObj;
        }

        @Override
        protected DaoFactoryBean getDaoFactoryBean() {
            return daoFactoryBean;
        }

        @Override
        protected Berechtigung findByID(final Long oid) {
            return getEntityDAO().findByID(oid);
        }

        @Override
        protected LogEventEntryWriterBean getLogger() {
            return logEventEntryWriterBean;
        }
    };


    private BerechtigungDAO getEntityDAO() {
        return daoFactoryBean.getBerechtigungDAO();
    }

    //
    //    public
    //    @WebMethod(operationName = "saveOrUpdateTX")
    //    @WebResult(name = "BerechtigungResult")
    //    BerechtigungResult loadBerechtigung(@WebParam(name = "sessionID", mode = WebParam.Mode.IN) final String sessionid,
    //                                        @WebParam(name = "UID", mode = WebParam.Mode.IN) final Long uid,
    //                                        @WebParam(name = "name", mode = WebParam.Mode.IN) final String name){
    //        return createResult(getEntityDAO().loadBerechtigung(name));
    //    }

    @WebResult(name = "BerechtigungResult")

    @WebMethod(operationName = "loadRevisionFor")
    public
    BerechtigungResult loadRevisionFor(@WebParam(name = "sessionID", mode = WebParam.Mode.IN) final String sessionid, @WebParam(name = "UID", mode = WebParam.Mode.IN) final Long uid, @WebParam(name = "oid", mode = WebParam.Mode.IN) final Long oid) {
        final List<Berechtigung> list = getEntityDAO().loadAllRevisionsFor(oid);
        return createResult(list);
    }


    @WebResult(name = "BerechtigungResult")
    @WebMethod(operationName = "saveOrUpdateTX")

    public
    BerechtigungResult saveOrUpdateTX(@WebParam(name = "sessionID", mode = WebParam.Mode.IN) final String sessionid, @WebParam(name = "UID", mode = WebParam.Mode.IN) final Long uid,
                                      @WebParam(name = "entity", mode = WebParam.Mode.IN) final FlatBerechtigung entity) {

        return crudExecuter.saveOrUpdate(sessionid, uid, entity);
    }

    @WebResult(name = "BerechtigungResult")
    @WebMethod(operationName = "removeTX")

    public
    BerechtigungResult removeTX(@WebParam(name = "sessionID", mode = WebParam.Mode.IN) final String sessionid, @WebParam(name = "UID", mode = WebParam.Mode.IN) final Long uid, @WebParam(name = "oid", mode = WebParam.Mode.IN) final Long oid) {
        return crudExecuter.remove(sessionid, uid, oid);
    }

    @WebResult(name = "BerechtigungResult")
    @WebMethod(operationName = "findByID")

    public
    BerechtigungResult findByID(@WebParam(name = "sessionID", mode = WebParam.Mode.IN) final String sessionid, @WebParam(name = "UID", mode = WebParam.Mode.IN) final Long uid, @WebParam(name = "oid", mode = WebParam.Mode.IN) final Long oid) {
        final Berechtigung byID = getEntityDAO().findByID(oid);
        if (byID == null) {
            return new BerechtigungResult();
        } else {
            return createResult(byID);
        }
    }

    @WebResult(name = "BerechtigungResult")
    @WebMethod(operationName = "loadWithOIDList")

    public
    BerechtigungResult loadWithOIDList(@WebParam(name = "sessionID", mode = WebParam.Mode.IN) final String sessionid, @WebParam(name = "UID", mode = WebParam.Mode.IN) final Long uid,
                                       @WebParam(name = "oidliste", mode = WebParam.Mode.IN) final List<Long> oids) {
        return createResult(getEntityDAO().loadWithOIDList(oids));
    }

    @WebResult(name = "BerechtigungResult")
    @WebMethod(operationName = "loadAllEntities")

    public
    BerechtigungResult loadAllEntities(@WebParam(name = "sessionID", mode = WebParam.Mode.IN) final String sessionid, @WebParam(name = "UID", mode = WebParam.Mode.IN) final Long uid) {
        return createResult(getEntityDAO().loadAllEntities());
    }

    private BerechtigungResult createResult(final Berechtigung... typeObj) {
        final BerechtigungResult result = new BerechtigungResult();
        for (final Berechtigung berechtigung : typeObj) {
            result.getObjList().add(berechtigung);
        }
        return result;
    }

    private BerechtigungResult createResult(final Collection<Berechtigung> typeObj) {
        final BerechtigungResult result = new BerechtigungResult();
        for (final Berechtigung berechtigung : typeObj) {
            result.getObjList().add(berechtigung);
        }
        return result;
    }


    public static class FlatBerechtigung extends BaseFlatEntity {
        private String name;

        public String getName() {
            return name;
        }

        public void setName(final String name) {
            this.name = name;
        }
    }

    public static class BerechtigungResult extends BaseOrmResult<Berechtigung> {
        //        private List<Berechtigung> berechtigungList = new ArrayList<Berechtigung>();
        //
        //        public List<Berechtigung> getBerechtigungList(){
        //            return berechtigungList;
        //        }
        //
        //        public void setBerechtigungList(final List<Berechtigung> berechtigungList){
        //            this.berechtigungList = berechtigungList;
        //        }

        public List<Berechtigung> getObjList() {
            return objList;
        }

        public void setObjList(final List<Berechtigung> objList) {
            this.objList = objList;
        }
    }

}
